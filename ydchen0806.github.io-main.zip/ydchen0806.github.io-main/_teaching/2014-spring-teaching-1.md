---
title: "XMU Wiserclub--Data Mining"
collection: teaching
type: "Club activity"
permalink: /teaching/2021-2022-wiser-club
venue: "Xiamen University, WISER Club"
date: 2021-08-01
location: "Xiamen, China"
---

Responsible for designing and discussing the Data Mining course. Delivered lectures on **Clustering** and **Feature Extraction** topics.

<!-- Heading 1
======

Heading 2
======

Heading 3
====== -->